def test_empty():
    assert True
