Running on Binder
---------------------------

1. Go to https://mybinder.org/

2. Enter https://github.com/NeuroTechX/eeg-notebooks

3. Navigate to the sandbox folder and run the example analysis-only notebooks

