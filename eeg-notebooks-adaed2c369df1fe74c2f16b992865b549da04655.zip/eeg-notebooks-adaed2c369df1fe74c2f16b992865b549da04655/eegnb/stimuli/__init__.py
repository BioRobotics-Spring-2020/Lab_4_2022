from os import path

FACE_HOUSE = path.join(path.dirname(__file__), "visual", "face_house")
CAT_DOG = path.join(path.dirname(__file__), "visual", "cats_dogs")
